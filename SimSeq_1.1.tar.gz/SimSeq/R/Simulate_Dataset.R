pval.hist<-function(p)
  
{
  m<-length(p)                            # count the p-values 
  h.cdf<-h.pdf<-p.edf<-rep(NA,length(p))  # initialize h.pdf and p.edf vectors
  ord<-order(p)                           # order the p-values
  p.edf[ord]<-(1:m)/(m+1)                 # define the EDF estimator
  hh<-NULL                                # initialize the histogram heights 
  F0<-p0<-b.edf<-p.brks<-1                # initialize vectors with F0, p0, EDF break-points, and p-value break-points
  
  while(any(p<p0))  # Loop until all p-values are included in the histogram
  {
    slp<-min(1,(2*sum(p[p<p0])+1)/(1+p0*m))  # deterime the average abundance of p-values (under conditional uniform)
    slp.line<-(1-slp*(p0-p)/p0)*F0           # represent this line as a straight line in the EDF  
    ok<-(p<p0)&(p.edf>=slp.line)             # find the p-values that are "OK"
    if (any(ok))                             # Insert a new histogram break-point
    {
      p.cut<-min(p[ok])                   # Find the minimum p-value that is OK
      p.brks<-c(p.cut,p.brks)             # Update the p-value break-point vector
      hh<-c(slp,hh)                       # Update the histogram heights vector 
      p0<-p.cut                           # Update p0
      F0<-min(p.edf[p>=p0])               # Update F0
      b.edf<-c(F0,b.edf)                  # Update the break-points in the EDF histogram estimator
    }
    else # inserts a (p,EDF) point at (0,0)
    {
      p.brks<-c(0,min(p),max(p[p<p0]),p.brks) 
      b.edf<-c(0,min(p.edf[p==min(p)]),min(p.edf[p==max(p[p<p0])]),b.edf)
      p0<-0
    }
  }
  
  last.pt<-min((1:length(p.brks))[p.brks==1])
  p.brks<-p.brks[1:last.pt]
  b.edf<-b.edf[1:last.pt]
  
  p.diffs<-diff(p.brks)
  zero.diffs<-(1:length(p.diffs))[p.diffs==0]
  if (length(zero.diffs)>0)
  {
    p.brks<-p.brks[-(zero.diffs+1)]
    b.edf<-b.edf[-(zero.diffs+1)]   
  }
  
  hh<-exp(log(diff(b.edf))-log(diff(p.brks)))  
  if (any(is.na(hh)))
  {
    print(summary(p))
    print(p.brks)
    print(b.edf)
    print(hh)
    stop("undefined histogram heights.")
    
  } 
  hd<-diff(hh)  # Difference in histogram heights
  p1<-1
  while(any(hd>0))  # Enforce monotonicity
  {
    k<-max((1:length(hd))[hd>0])                        # Find largest histogram bar index k such that bar k is shorter than bar k+1
    p.brks<-c(p.brks[1:k],p.brks[(k+2):length(p.brks)]) # combine histogram bars k and k+1
    b.edf<-c(b.edf[1:k],b.edf[(k+2):length(b.edf)])     # update EDF break-points with monotonocity constraint      
    hh<-exp(log(diff(b.edf))-log(diff(p.brks)))         # compute new histogram heights
    hd<-diff(hh)                                        # compare consecutive histogram heights
  }
  
  h.cdf<-approx(p.brks,b.edf,xout=p)$y                  # Get the histogram-based CDF estimates for each p-value
  p.hist<-exp(log(diff(b.edf))-log(diff(p.brks)))       # Get the height for each histogram bar
  pi0.hat<-min(p.hist)                                  # Get the pi0 estimate from the histogram
  h.ebp<-approx(p.brks,pi0.hat/c(p.hist,p.hist[length(p.hist)]),xout=p)$y # Get the conservative EBP interpolation
  h.fdr<-exp(log(min(pi0.hat))+log(p)-log(h.cdf))                         # Get the histogram-based FDR estimate
  h.ebp[p==0]=0
  h.fdr[p==0]=0
  
  return(list(p=p,              # input p-value vector
              edf=p.edf,        # the p-value edf
              h.cdf=h.cdf,      # the histogram-based cdf estimate
              h.fdr=h.fdr,      # the histogram-based FDR estimate
              h.ebp=h.ebp,      # the histogram-based EBP estimate
              p.brks=p.brks,    # the p-value break-points of the histogram
              p.hist=p.hist,    # the heights of each histogram bar
              edf.brks=b.edf,   # the break-points in the EDF of the histogram estimator
              pi0.hat=pi0.hat)) # the histogram-based estimate of the proportion of tests with a true null hypothesis
}

sortdata <- function(counts,replicate,treatment,sort.method,offset)
{
  if(!sort.method %in% c("paired","unpaired")) stop("sort.method must be either paired or unpaired")
  if(length(replicate) != length(treatment)) stop("Length of replicate must equal length of treatment")
  if(any(table(replicate) > 2)) stop("Number of treatment groups per replicate must not be greater than 2")
  if(length(unique(treatment)) > 2) stop("Number of treatment groups per replicate must not be greater than 2")
    
   if (sort.method=="paired"){ 
    sorting <- order(replicate,treatment,decreasing=T)
    counts <- counts[,sorting]
    replicate <- replicate[sorting]
    treatment <- treatment[sorting]
    offset <- offset[sorting]
    counts <- counts[,replicate %in% unique(replicate)[rev(tabulate(replicate)) == 2]]
    treatment <- treatment[replicate %in% unique(replicate)[rev(tabulate(replicate)) == 2]]
    offset <- offset[replicate %in% unique(replicate)[rev(tabulate(replicate)) == 2]]
    replicate <- replicate[replicate %in% unique(replicate)[rev(tabulate(replicate)) == 2]]
    }
  
    if(sort.method=="unpaired"){
      sorting <- order(treatment)
      replicate <- replicate[sorting]
      treatment <- treatment[sorting]
      counts <- counts[,sorting]
      offset <- offset[sorting]
    }
    
    return(list(counts=counts,replicate=factor(replicate),treatment=factor(treatment),offset=offset))
}

samp.col <- function(n.col,k.ind,sort.method,treatment){
  if(sort.method == "paired"){
    evens <- seq(2,n.col,by=2)
    samp <- sample(evens,2*k.ind,replace=F)
    samp <- c(samp,samp-1)
  }
  if(sort.method == "unpaired"){  
    trt1 <- 1:table(treatment)[1]
    trt2 <- (table(treatment)[1]+1):length(treatment)
    samp <- c(sample(trt1,2*k.ind),sample(trt2,2*k.ind))
  }
  samp <- as.numeric(samp)
  return(samp)
}

data.sim <- function(counts,n.genes,n.diff,k.ind,genes.select=NULL,genes.diff = NULL,
                     probs=NULL,EBP=NULL,exact=F,power=1,
                     offset=NULL,samp.method="standard",
                     sort.method="paired",replicate,treatment,
                     n1.genes=NULL,n1.diff=NULL,
                     genes1.select=NULL,genes1.diff=NULL){
  
  counts <- as.matrix(counts)
  if(any(!is.numeric(counts))) stop("counts matrix contains non-numeric values")
  n.row <- dim(counts)[1]
  n.col <- dim(counts)[2]
  
  if(!is.null(n.genes)){
    if(!is.numeric(n.genes)) stop("Number of genes selected, n.genes, must be a positive integer less than total number of rows counts matrix")
    else if(round(n.genes) != n.genes | n.genes > n.row | n.genes <= 0) stop("Number of genes selected, n.genes, must be a positive integer less than total number of rows counts matrix")
  }
  
  if(!is.null(n.diff)){
    if(!is.numeric(n.diff)) stop("Number of DEgenes, n.diff, must be a positive integer less than n.genes")
    else if(round(n.diff) != n.diff |n.diff > n.genes | n.diff <= 0) stop("Number of DEgenes, n.diff, must be a positive integer less than n.genes")
  }
  
  if(!is.null(k.ind)){
    if(!is.numeric(k.ind)) stop("Number of replicates in each treatment group, k.ind, must be a positive integer less than total number of columns in counts matrix divided by two")
    else if(!is.numeric(k.ind) | round(k.ind) != k.ind | k.ind > n.col/2 | k.ind <=0) stop("Number of replicates in each treatment group, k.ind, must be a positive integer less than total number of columns in counts matrix divided by two")
  }
  
  if(!is.null(genes.select)){
    if(!is.numeric(genes.select) & !is.logical(genes.select)) stop("genes.select must either be NULL or numeric or logical vector")
    if(is.numeric(genes.select)) n.genes <- length(genes.select)
    if(is.logical(genes.select)){
      if(length(genes.select) != n.row) stop("When genes.select is a logical vector, its length must equal the number of rows of the counts matrix") 
      else genes.select <- which(genes.select); n.genes <- length(genes.select) 
    }   
  }
  
  if(is.null(n.genes) & is.null(genes.select)) stop("At least one of n.genes and genes.select must not have a value of NULL")
  if(is.null(genes.select) & !is.null(genes.diff)) stop("genes.diff cannot be specified without also specifying genes.select")
  
  if(!is.null(genes.select) & !is.null(genes.diff)){
    if(!is.numeric(genes.diff) & !is.logical(genes.diff)) stop("genes.diff must either be NULL or a numeric or logical vector")
    if(is.numeric(genes.diff)){
      n.diff <- length(genes.diff)
      if(any(!genes.diff %in% genes.subset)) stop("genes.diff must be a subset of genes.select") 
    } 
    if(is.logical(genes.diff)){
      if(length(genes.diff) != length(genes.select)) stop("When genes.diff is a logical vector, length of genes.diff must equal number of genes.select")
      else genes.diff <- genes.select[which(genes.diff)]; n.diff <- length(genes.diff) 
    }  
  }
  
  if(!is.null(probs)){
    if(!is.numeric(probs) | any(probs >1) | any(probs < 0) | length(probs) != n.row) stop("probs must be a numeric vector of length equal to the number of rows in the counts matrix with each entry between 0 and 1") 
  }
  
  if(!is.null(EBP)){
    if(!is.numeric(EBP) | any(EBP > 1) | any(EBP < 1)) stop("EBP must be a numeric vector of length equal to the number of rows of the counts matrix with each entry between 0 and 1") 
  }
  
  if(is.null(offset)) offset <- rep(1,n.col) 
  if(!is.null(offset)){
    if(!is.numeric(offset) | any(offset <= 0) | length(offset) != n.col) stop("offset must be a positive numeric vector with length equal to the number of columns in the counts matrix")
  }
  
  if(!samp.method %in% c("standard","independent")) stop("samp.method must be either standard or independent")
  if(!sort.method %in% c("paired","unpaired")) stop("sort.method must be either paired or unpaired")  
  
  if(length(replicate) != length(treatment)) stop("Length of replicate must equal length of treatment")
  if(any(table(replicate) > 2)) stop("Number of treatment groups per replicate must not be greater than 2")
  if(length(unique(treatment)) > 2) stop("Number of treatment groups per replicate must not be greater than 2")
  
  if(!is.null(n1.genes)){
    if(!is.numeric(n1.genes)) stop("Number of genes selected in first treatment group, n1.genes, must be a positive integer less than n.genes")
      else if(round(n1.genes) != n1.genes | n1.genes > n.genes | n1.genes < 0) stop("Number of genes selected in first treatment group, n1.genes, must be a positive integer less than n.genes")
  }
  
  if(!is.null(n1.diff)){
    if(!is.numeric(n1.diff)) stop("Number of genes selected to be differentially expressed in first treatment group, n1.diff, must be a positive integer less than n.diff")
      else if(round(n1.diff) != n1.diff | n1.diff > n.diff | n1.diff < 0) stop("Number of genes selected to be differentially expressed in first treatment group, n1.diff, must be a positive integer less than n.diff")
  }
  
  if(!is.null(sort.method)) {
    sort.list <- sortdata(counts,replicate,treatment,sort.method,offset)
    counts <- sort.list[[1]]
    replicate <- sort.list[[2]]
    treatment <- sort.list[[3]]
    offset <- sort.list[[4]]
  }
  n.row <- dim(counts)[1]
  n.col <- dim(counts)[2]
  if(is.null(n1.genes)) n1.genes <- n.genes
  if(is.null(n1.diff)) n1.diff <- n.diff
  
  if(is.null(probs) & is.null(EBP)){
    if(is.null(genes.select) | is.null(genes.diff)){
      if(sort.method=="paired"){
        odds <- seq(from=1,to=n.col,by=2)
        diff1 <- t(counts[,odds]+1)/offset[odds] 
        diff2 <- t(counts[,(odds+1)]+1)/offset[(odds+1)]
        diff <- log(t(diff1/diff2))
        
        probs <- numeric(n.row)
        for (i in 1:n.row) probs[i] <- wilcox.test(diff[i,],exact=exact)$p.value
  }
     if(sort.method=="unpaired"){
       seq.trt1 <- 1:table(treatment)[1]
       trt1 <- log(t(t(counts[,seq.trt1]+1)/offset[seq.trt1]))
       trt2 <- log(t(t(counts[,-seq.trt1]+1)/offset[-seq.trt1]))
       probs <- numeric(n.row)
       for (i in 1:n.row) probs[i] <- wilcox.test(trt1[i,],trt2[i,],exact=exact)$p.value
     }
   }  
  }
  
  if(is.null(EBP)){
    if(is.null(genes.select) | is.null(genes.diff)) EBP <- pval.hist(probs)$h.ebp
  } 
  
  if(is.null(genes.select)){
  genes <- 1:n.row
  genes.diff <- sample(1:n.row,n.diff,prob=(1-EBP)^power,replace=F)
  genes.diff1 <- genes.diff[1:n1.diff]
  genes.diff2 <- genes.diff[-(1:n1.diff)]
  genes.equiv <- sample(genes[-genes.diff],n.genes-n.diff,replace=F)
  genes.subset1 <- c(genes.equiv[1:(n1.genes-n1.diff)],genes.diff1)
  genes.subset2 <- c(genes.equiv[-(1:(n1.genes-n1.diff))],genes.diff2)
  DEgenes1 <- genes.subset1 %in% genes.diff1
  DEgenes2 <- genes.subset2 %in% genes.diff2
  genes.subset <- c(genes.subset1,genes.subset2)
  DEgenes <- c(DEgenes1,DEgenes2)
  }
  
  if(length(genes.select)==n.genes & is.null(genes.diff)){
    genes.subset <- genes.select
    genes.diff <- sample(genes.subset,n.diff,prob=(1-EBP[genes.select])^power,replace=F)
    genes.diff1 <- genes.diff[1:n1.diff]
    genes.diff2 <- genes.diff[-(1:n1.diff)]
    genes.subset1 <- c(genes.subset[!genes.subset %in% genes.diff][1:(n1.genes-n1.diff)],genes.diff1)
    genes.subset2 <- c(genes.subset[!genes.subset %in% genes.diff][-(1:(n1.genes-n1.diff))],genes.diff2)
    DEgenes1 <- genes.subset1 %in% genes.diff1
    DEgenes2 <- genes.subset2 %in% genes.diff2
    genes.subset <- c(genes.subset1,genes.subset2)
    DEgenes <- c(DEgenes1,DEgenes2)
  }
  
  if(length(genes.select)==n.genes & length(genes.diff)==n.diff & is.null(genes1.select)){
    genes.subset <- genes.select
    genes.diff1 <- genes.diff[1:n1.diff]
    genes.diff2 <- genes.diff[-(1:n1.diff)]
    genes.subset1 <- c(genes.subset[!genes.subset %in% genes.diff][1:(n1.genes-n1.diff)],genes.diff1)
    genes.subset2 <- c(genes.subset[!genes.subset %in% genes.diff][-(1:(n1.genes-n1.diff))],genes.diff2)
    DEgenes1 <- genes.subset1 %in% genes.diff1
    DEgenes2 <- genes.subset2 %in% genes.diff2
    genes.subset <- c(genes.subset1,genes.subset2)
    DEgenes <- c(DEgenes1,DEgenes2)
  }
  
  if(length(genes.select)==n.genes & length(genes.diff)==n.diff & length(genes1.select)==n1.genes & is.null(genes1.diff)){
    genes.subset <- genes.select
    genes.subset1 <- genes1.select
    genes.subset2 <- which(!genes.select %in% genes1.select)
    genes.diff1 <- genes.diff[1:n1.diff]
    genes.diff2 <- genes.diff[-(1:n1.diff)]
    DEgenes1 <- genes.subset1 %in% genes.diff1
    DEgenes2 <- genes.subset2 %in% genes.diff2
    genes.subset <- c(genes.subset1,genes.subset2)
    DEgenes <- c(DEgenes1,DEgenes2)
  }
  
  if(length(genes.select)==n.genes & length(genes.diff)==n.diff & length(genes1.select)==n1.genes & length(genes1.diff)==n1.diff){
    genes.subset <- genes.select
    genes.subset1 <- genes1.select
    genes.subset2 <- which(!genes.select %in% genes1.select)
    genes.diff1 <- genes1.diff
    genes.diff2 <- which(!genes.diff %in% genes1.diff)
    DEgenes1 <- genes.subset1 %in% genes.diff1
    DEgenes2 <- genes.subset2 %in% genes.diff2
    genes.subset <- c(genes.subset1,genes.subset2)
    DEgenes <- c(DEgenes1,DEgenes2)
  }
  
  if(samp.method=="standard"){
    samp <- samp.col(n.col,k.ind,sort.method,treatment)
    offset.col <- offset[samp]
    data1 <- counts[genes.subset1,samp]
    data.table1 <- data1[,(2*k.ind+1):(2*(2*k.ind))]
    data.table1[DEgenes1,1:k.ind] <- 
      round(t(t(data1[DEgenes1,1:k.ind])/offset.col[1:k.ind]*offset.col[(2*k.ind+1):(3*k.ind)]))
    data2 <- counts[genes.subset2,samp]
    data.table2 <- data2[,1:(2*k.ind)]
    data.table2[DEgenes2,1:k.ind] <- 
      round(t(t(data2[DEgenes2,(2*k.ind+1):(3*k.ind)])/offset.col[(2*k.ind+1):(3*k.ind)]*offset.col[1:k.ind]))
    data.table <- rbind(data.table1,data.table2)
  }
  
  if(samp.method=="independent"){
    samp <- t(replicate(n.genes,samp.col(n.col,k.ind,sort.method,treatment)))
    offset.col <- apply(samp,2,function(x) offset[x])
    samp1 <- samp[1:n1.genes,]
    offset.col1 <- offset.col[1:n1.genes,]
    data.temp1 <- counts[genes.subset1,]
    data1 <- matrix(mapply(function(x,y) data.temp1[x,y],x=1:n1.genes,y=samp1,SIMPLIFY=T),ncol=4*k.ind)
    data.table1 <- data1[,(2*k.ind+1):(2*(2*k.ind))]
      for(j in 1:n1.diff){
        data.table1[DEgenes1,1:k.ind][j,] <- 
          round(t(t(data1[DEgenes1,1:k.ind][j,])/offset.col[j,1:k.ind]*offset.col[j,(2*k.ind+1):(3*k.ind)]))
      }
    samp2 <- samp[-(1:n1.genes),]
    offset.col2 <- offset.col[-(1:n1.genes),]
    data.temp2 <- counts[genes.subset2,]
    data2 <- matrix(mapply(function(x,y) data.temp2[x,y],x=1:(n.genes-n1.genes),y=samp2,SIMPLIFY=T),ncol=4*k.ind)
    data.table2 <- data2[,1:(2*k.ind)]
    for(j in 1:(n.diff-n1.diff)){
      data.table2[DEgenes2,1:k.ind][j,] <- 
        round(t(t(data2[DEgenes2,(2*k.ind+1):(3*k.ind)][j,])/offset.col[j,(2*k.ind+1):(3*k.ind)]*offset.col[j,1:k.ind]))
    }
    data.table <- rbind(data.table1,data.table2)
  }
  return(list(counts=data.table,genes.select=genes.subset,DEgenes=DEgenes))
}


