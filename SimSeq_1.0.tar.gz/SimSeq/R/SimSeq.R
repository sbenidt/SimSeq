pval.hist<-function(p)
  
{
  m<-length(p)                            # count the p-values 
  h.cdf<-h.pdf<-p.edf<-rep(NA,length(p))  # initialize h.pdf and p.edf vectors
  ord<-order(p)                           # order the p-values
  p.edf[ord]<-(1:m)/(m+1)                 # define the EDF estimator
  hh<-NULL                                # initialize the histogram heights 
  F0<-p0<-b.edf<-p.brks<-1                # initialize vectors with F0, p0, EDF break-points, and p-value break-points
  
  while(any(p<p0))  # Loop until all p-values are included in the histogram
  {
    slp<-min(1,(2*sum(p[p<p0])+1)/(1+p0*m))  # deterime the average abundance of p-values (under conditional uniform)
    slp.line<-(1-slp*(p0-p)/p0)*F0           # represent this line as a straight line in the EDF  
    ok<-(p<p0)&(p.edf>=slp.line)             # find the p-values that are "OK"
    if (any(ok))                             # Insert a new histogram break-point
    {
      p.cut<-min(p[ok])                   # Find the minimum p-value that is OK
      p.brks<-c(p.cut,p.brks)             # Update the p-value break-point vector
      hh<-c(slp,hh)                       # Update the histogram heights vector 
      p0<-p.cut                           # Update p0
      F0<-min(p.edf[p>=p0])               # Update F0
      b.edf<-c(F0,b.edf)                  # Update the break-points in the EDF histogram estimator
    }
    else # inserts a (p,EDF) point at (0,0)
    {
      p.brks<-c(0,min(p),max(p[p<p0]),p.brks) 
      b.edf<-c(0,min(p.edf[p==min(p)]),min(p.edf[p==max(p[p<p0])]),b.edf)
      p0<-0
    }
  }
  
  last.pt<-min((1:length(p.brks))[p.brks==1])
  p.brks<-p.brks[1:last.pt]
  b.edf<-b.edf[1:last.pt]
  
  p.diffs<-diff(p.brks)
  zero.diffs<-(1:length(p.diffs))[p.diffs==0]
  if (length(zero.diffs)>0)
  {
    p.brks<-p.brks[-(zero.diffs+1)]
    b.edf<-b.edf[-(zero.diffs+1)]   
  }
  
  hh<-exp(log(diff(b.edf))-log(diff(p.brks)))  
  if (any(is.na(hh)))
  {
    print(summary(p))
    print(p.brks)
    print(b.edf)
    print(hh)
    stop("undefined histogram heights.")
    
  } 
  hd<-diff(hh)  # Difference in histogram heights
  p1<-1
  while(any(hd>0))  # Enforce monotonicity
  {
    k<-max((1:length(hd))[hd>0])                        # Find largest histogram bar index k such that bar k is shorter than bar k+1
    p.brks<-c(p.brks[1:k],p.brks[(k+2):length(p.brks)]) # combine histogram bars k and k+1
    b.edf<-c(b.edf[1:k],b.edf[(k+2):length(b.edf)])     # update EDF break-points with monotonocity constraint      
    hh<-exp(log(diff(b.edf))-log(diff(p.brks)))         # compute new histogram heights
    hd<-diff(hh)                                        # compare consecutive histogram heights
  }
  
  h.cdf<-approx(p.brks,b.edf,xout=p)$y                  # Get the histogram-based CDF estimates for each p-value
  p.hist<-exp(log(diff(b.edf))-log(diff(p.brks)))       # Get the height for each histogram bar
  pi0.hat<-min(p.hist)                                  # Get the pi0 estimate from the histogram
  h.ebp<-approx(p.brks,pi0.hat/c(p.hist,p.hist[length(p.hist)]),xout=p)$y # Get the conservative EBP interpolation
  h.fdr<-exp(log(min(pi0.hat))+log(p)-log(h.cdf))                         # Get the histogram-based FDR estimate
  h.ebp[p==0]=0
  h.fdr[p==0]=0
  
  return(list(p=p,              # input p-value vector
              edf=p.edf,        # the p-value edf
              h.cdf=h.cdf,      # the histogram-based cdf estimate
              h.fdr=h.fdr,      # the histogram-based FDR estimate
              h.ebp=h.ebp,      # the histogram-based EBP estimate
              p.brks=p.brks,    # the p-value break-points of the histogram
              p.hist=p.hist,    # the heights of each histogram bar
              edf.brks=b.edf,   # the break-points in the EDF of the histogram estimator
              pi0.hat=pi0.hat)) # the histogram-based estimate of the proportion of tests with a true null hypothesis
}

sortdata <- function(counts,replicate,treatment,sort.method)
{
  if(!sort.method %in% c("paired","unpaired")) stop("sort.method must be either paired or unpaired")
  if(length(replicate) != length(treatment)) stop("Length of replicate must equal length of treatment")
  if(any(table(replicate) > 2)) stop("Number of treatment groups per replicate must not be greater than 2")
  if(length(unique(treatment)) > 2) stop("Number of treatment groups per replicate must not be greater than 2")
    
   if (sort.method=="paired"){ 
    sorting <- order(replicate,treatment,decreasing=T)
    counts <- counts[,sorting]
    replicate <- replicate[sorting]
    treatment <- treatment[sorting]
    counts <- counts[,replicate %in% unique(replicate)[rev(tabulate(replicate)) == 2]]
    treatment <- treatment[replicate %in% unique(replicate)[rev(tabulate(replicate)) == 2]]
    replicate <- replicate[replicate %in% unique(replicate)[rev(tabulate(replicate)) == 2]]
    }
  
    if(sort.method=="unpaired"){
      sorting <- order(treatment)
      replicate <- replicate[sorting]
      treatment <- treatment[sorting]
      counts <- counts[,sorting]
    }
    return(list(counts=counts,replicate=factor(replicate),treatment=factor(treatment)))
}

samp.col <- function(n.col,k.ind,sort.method,treatment){
  if(sort.method == "paired"){
    evens <- seq(2,n.col,by=2)
    samp <- sample(evens,2*k.ind,replace=F)
    samp <- c(samp,samp-1)
  }
  if(sort.method == "unpaired"){  
    trt1 <- 1:table(treatment)[1]
    trt2 <- (table(treatment)[1]+1):length(treatment)
    samp <- c(sample(trt1,k.ind),sample(trt2,2*k.ind))
  }
  samp <- as.numeric(samp)
  return(samp)
}

data.sim <- function(counts,n.genes=5000,n.diff=1000,k.ind=5,
                     genes.select=NULL,EBP=NULL,probs=NULL,
                     exact=F,power=1,genes.diff = NULL,
                     offset=NULL,samp.method="standard",
                     sort.method="paired",replicate,treatment){
  
  counts <- as.matrix(counts)
  if(!is.null(sort.method)) {
    sort.list <- sortdata(counts,replicate,treatment,sort.method)
    counts <- sort.list[[1]]
    replicate <- sort.list[[2]]
    treatment <- sort.list[[3]]
  }
  n.row <- dim(counts)[1]
  n.col <- dim(counts)[2]
  
  if(n.genes > n.row) stop("n.genes must be less than total number of rows Dataset")
  if(n.genes < n.diff) stop("Number of n.diff genes must be less than n.genes")
  if(k.ind > n.col/2) stop("Number of replicates in each treatment cannot exceed number of columns in dataset")
  if(!samp.method %in% c("standard","independent")) stop("samp.method must be either standard or independent")
  
  if(is.null(offset)) offset <- rep(1, n.col)
  
  if(is.null(probs) & is.null(genes.select) & is.null(EBP)){
    if(sort.method=="paired"){
      odds <- seq(from=1,to=n.col,by=2)
      diff1 <- t(counts[,odds]+1)/offset[odds] 
      diff2 <- t(counts[,(odds+1)]+1)/offset[(odds+1)]
      diff <- log(t(diff1/diff2))
      
      probs <- numeric(n.row)
      for (i in 1:n.row) probs[i] <- wilcox.test(diff[i,],exact=exact)$p.value
  }
   if(sort.method=="unpaired"){
     seq.trt1 <- 1:table(treatment)[1]
     trt1 <- log(t(t(counts[,seq.trt1]+1)/offset[seq.trt1]))
     trt2 <- log(t(t(counts[,-seq.trt1]+1)/offset[-seq.trt1]))
     probs <- numeric(n.row)
     for (i in 1:n.row) probs[i] <- wilcox.test(trt1[i,],trt2[i,],exact=exact)$p.value
   }  
  }
  
  if(is.null(genes.select) & is.null(EBP)) EBP <- pval.hist(probs)$h.ebp

  if(is.null(genes.select)){
  genes <- 1:n.row
  genes.diff <- sample(1:n.row,n.diff,prob=(1-EBP)^power,replace=F)
  genes.subset <- as.numeric(c(genes.diff,sample(genes[-genes.diff],n.genes-n.diff,replace=F)))
  DEgenes <- genes.subset %in% genes.diff
  }
  
  if(length(genes.select)==n.genes){
    genes.subset <- genes.select
    DEgenes <- genes.subset %in% genes.diff
  }
  
  if(samp.method=="standard" & sort.method=="paired"){
    samp <- samp.col(n.col,k.ind,sort.method,treatment)
    offset.col <- offset[samp]
    data <- counts[genes.subset,samp]
    data.table <- data[,(2*k.ind+1):(2*(2*k.ind))]
    data.table[DEgenes,1:k.ind] <- 
      round(t(t(data[DEgenes,1:k.ind])/offset.col[1:k.ind]*offset.col[(2*k.ind+1):(3*k.ind)]))
  }
   
  if(samp.method=="standard" & sort.method=="unpaired"){
    samp <- samp.col(n.col,k.ind,sort.method,treatment)
    offset.col <- offset[samp]
    data <- counts[genes.subset,samp]
    data.table <- data[,-(1:k.ind)]
    data.table[DEgenes,1:k.ind] <- 
      round(t(t(data[DEgenes,1:k.ind])/offset.col[1:k.ind]*offset.col[(k.ind+1):(2*k.ind)]))
  }
  
  if(samp.method=="independent" & sort.method=="paired"){
    samp <- t(replicate(n.genes,samp.col(n.col,k.ind,sort.method,treatment)))
    offset.col <- apply(samp,2,function(x) offset[x])
    data.temp <- counts[genes.subset,]
    data <- matrix(mapply(function(x,y) data.temp[x,y],x=1:n.genes,y=samp,SIMPLIFY=T),ncol=4*k.ind)
    data.table <- data[,(2*k.ind+1):(2*(2*k.ind))]
      for(j in 1:n.diff){
        data.table[DEgenes,1:k.ind][j,] <- 
          round(t(t(data[DEgenes,1:k.ind][j,])/offset.col[j,1:k.ind]*offset.col[j,(2*k.ind+1):(3*k.ind)]))
    }
  }
  
  if(samp.method=="independent" & sort.method=="unpaired"){
    samp <- t(replicate(n.genes,samp.col(n.col,k.ind,sort.method,treatment)))
    offset.col <- apply(samp,2,function(x) offset[x])
    data.temp <- counts[genes.subset,]
    data <- matrix(mapply(function(x,y) data.temp[x,y],x=1:n.genes,y=samp,SIMPLIFY=T),ncol=3*k.ind)
    data.table <- data[,-(1:k.ind)]
    for(j in 1:n.diff){
      data.table[DEgenes,1:k.ind][j,] <- 
        round(t(t(data[DEgenes,1:k.ind][j,])/offset.col[j,1:k.ind]*offset.col[j,(k.ind+1):(2*k.ind)]))
    }
  }
  return(list(counts=data.table,genes.select=genes.subset,DEgenes=DEgenes))
}


